'use strict'
function main() {
    let gameinfo = document.getElementById('pill-grid')
    //preparation
    definition.data()
    info.UpdateData(1, "low", 4)
    info.Create()
    table.Create()
    table.VirusSpawn(4)
    //game
    game()

}
